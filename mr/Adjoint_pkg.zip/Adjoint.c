/*
 * File: Adjoint.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 26-Jul-2021 14:38:38
 */

/* Include Files */
#include "Adjoint.h"

/* Function Definitions */

/*
 * *** CHAPTER 3: RIGID-BODY MOTIONS ***
 *  Takes T a transformation matrix SE3.
 *  Returns the corresponding 6x6 adjoint representation [AdT].
 *  Example Input:
 *
 *  clear; clc;
 *  T = [[1, 0, 0, 0]; [0, 0, -1, 0]; [0, 1, 0, 3]; [0, 0, 0, 1]];
 *  AdT = Adjoint(T)
 *
 *  Output:
 *  AdT =
 *      1     0     0     0     0     0
 *      0     0    -1     0     0     0
 *      0     1     0     0     0     0
 *      0     0     3     1     0     0
 *      3     0     0     0     0    -1
 *      0     0     0     0     1     0
 * Arguments    : const double T[16]
 *                double AdT[36]
 * Return Type  : void
 */
void Adjoint(const double T[16], double AdT[36])
{
  double dv[9];
  int i;
  double d;
  double d1;
  double dv1[9];
  int AdT_tmp;
  int b_AdT_tmp;

  /*  *** CHAPTER 3: RIGID-BODY MOTIONS *** */
  /*  Takes the transformation matrix T in SE(3)  */
  /*  Returns R: the corresponding rotation matrix */
  /*          p: the corresponding position vector . */
  /*  Example Input: */
  /*   */
  /*  clear; clc; */
  /*  T = [[1, 0, 0, 0]; [0, 0, -1, 0]; [0, 1, 0, 3]; [0, 0, 0, 1]]; */
  /*  [R, p] = TransToRp(T) */
  /*   */
  /*  Output: */
  /*  R = */
  /*      1     0     0 */
  /*      0     0    -1 */
  /*      0     1     0 */
  /*  p = */
  /*      0 */
  /*      0 */
  /*      3 */
  /*  *** CHAPTER 3: RIGID-BODY MOTIONS *** */
  /*  Takes a 3-vector (angular velocity). */
  /*  Returns the skew symmetric matrix in so(3). */
  /*  Example Input: */
  /*   */
  /*  clear; clc; */
  /*  omg = [1; 2; 3]; */
  /*  so3mat = VecToso3(omg) */
  /*   */
  /*  Output: */
  /*  so3mat = */
  /*      0    -3     2 */
  /*      3     0    -1 */
  /*     -2     1     0 */
  dv[0] = 0.0;
  dv[3] = -T[14];
  dv[6] = T[13];
  dv[1] = T[14];
  dv[4] = 0.0;
  dv[7] = -T[12];
  dv[2] = -T[13];
  dv[5] = T[12];
  dv[8] = 0.0;
  for (i = 0; i < 3; i++) {
    d = dv[i + 3];
    d1 = dv[i + 6];
    for (AdT_tmp = 0; AdT_tmp < 3; AdT_tmp++) {
      b_AdT_tmp = AdT_tmp << 2;
      dv1[i + 3 * AdT_tmp] = (dv[i] * T[b_AdT_tmp] + d * T[b_AdT_tmp + 1]) + d1 *
        T[b_AdT_tmp + 2];
      AdT[AdT_tmp + 6 * i] = T[AdT_tmp + (i << 2)];
      AdT[AdT_tmp + 6 * (i + 3)] = 0.0;
    }
  }

  for (i = 0; i < 3; i++) {
    AdT[6 * i + 3] = dv1[3 * i];
    AdT_tmp = i << 2;
    b_AdT_tmp = 6 * (i + 3);
    AdT[b_AdT_tmp + 3] = T[AdT_tmp];
    AdT[6 * i + 4] = dv1[3 * i + 1];
    AdT[b_AdT_tmp + 4] = T[AdT_tmp + 1];
    AdT[6 * i + 5] = dv1[3 * i + 2];
    AdT[b_AdT_tmp + 5] = T[AdT_tmp + 2];
  }
}

/*
 * File trailer for Adjoint.c
 *
 * [EOF]
 */
