/*
 * File: Adjoint_terminate.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 26-Jul-2021 14:38:38
 */

#ifndef ADJOINT_TERMINATE_H
#define ADJOINT_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Adjoint_types.h"

/* Function Declarations */
extern void Adjoint_terminate(void);

#endif

/*
 * File trailer for Adjoint_terminate.h
 *
 * [EOF]
 */
