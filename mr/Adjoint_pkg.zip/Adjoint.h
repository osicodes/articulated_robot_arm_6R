/*
 * File: Adjoint.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 26-Jul-2021 14:38:38
 */

#ifndef ADJOINT_H
#define ADJOINT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Adjoint_types.h"

/* Function Declarations */
extern void Adjoint(const double T[16], double AdT[36]);

#endif

/*
 * File trailer for Adjoint.h
 *
 * [EOF]
 */
