/*
 * File: Adjoint_initialize.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 26-Jul-2021 14:38:38
 */

/* Include Files */
#include "Adjoint_initialize.h"
#include "Adjoint.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void Adjoint_initialize(void)
{
}

/*
 * File trailer for Adjoint_initialize.c
 *
 * [EOF]
 */
