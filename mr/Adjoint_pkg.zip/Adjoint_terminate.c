/*
 * File: Adjoint_terminate.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 26-Jul-2021 14:38:38
 */

/* Include Files */
#include "Adjoint_terminate.h"
#include "Adjoint.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void Adjoint_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for Adjoint_terminate.c
 *
 * [EOF]
 */
